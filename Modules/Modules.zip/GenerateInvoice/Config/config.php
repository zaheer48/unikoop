<?php

return [
    'name' => 'GenerateInvoice'
];
