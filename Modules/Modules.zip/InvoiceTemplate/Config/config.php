<?php

return [
    'name' => 'InvoiceTemplate'
];
