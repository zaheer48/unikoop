<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p> {!! $data['message'] !!} </p>
</body>
</html>